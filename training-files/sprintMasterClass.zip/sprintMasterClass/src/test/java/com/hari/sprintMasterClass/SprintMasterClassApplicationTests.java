package com.hari.sprintMasterClass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintMasterClassApplicationTests {

	@Test
	void contextLoads() {
	}

}

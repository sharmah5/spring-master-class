package com.hari.sprintMasterClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintMasterClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintMasterClassApplication.class, args);
	}

}
